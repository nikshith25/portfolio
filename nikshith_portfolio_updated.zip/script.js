
const typewriterText = "Hi, I'm Nikshith Kumar – AI Innovator & App Developer.";
let index = 0;
function typeWriter() {
  const el = document.querySelector('.typewriter');
  if (index < typewriterText.length) {
    el.textContent += typewriterText.charAt(index);
    index++;
    setTimeout(typeWriter, 80);
  }
}
window.onload = typeWriter;
